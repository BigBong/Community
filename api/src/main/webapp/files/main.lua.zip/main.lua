require "kit/lv_kit"
LIGHT_GRAY = 0xf5edb3
RED_COLOR = 0xf61d4b
BLUE_COLOR = 0x26a96d
GREEN_COLOR = 0x05A5D1
MAGENTA_COLOR = 0xff00ff
MOCCASIN_COLOR = 0xffe4b5
OLIVEDRAB_COLOR = 0x6b8e23
BALACK_COLOR = 0x000000
GRAY_COLOR=0xe2e2e2
WHITE_COLOR=0xFFFFFF
T10_ORANGE = 0xFFF2D7
T10_BLUE = 0xE7FCFE
T10_GRAY = 0xe1e1e1

local defSubColor = "#88888d"
local defTitleColor = "#000000"
local defTitle = "title"
local defSubTitle = "subTitle"

-- 分类标题高度
local unitHeight_C = 50
-- 分类广告banner高度
local unitHeight_Ads = 50
-- 横向单元格高度
local unitHeigth_H = 70
-- 竖直方向单元格高度
local unitHeight_V = 120
-- t10部分高度
local unitTopHeight = 140
-- 分类标题字体大小
local defCategoryTitle = 18
local defSubTextSize = 14
local defTagTextSize = 14

-- 小图尺寸
local defSmallSize = 50
-- 大图尺寸
local defBigSize = 70


w,h = System.screenSize()
scale = System.scale()
print("w:"..w.."\th:"..h.."\tscale:"..scale)

--- 判断数据是否为空
--- true  空
--- false 不为空
local function isEmpty(data)
    if data ~= nil then
        if #data == 0 then
            return true
        else
            return false
        end
    end

end

local function setWidth_Height(width,height)

    local _h = height
    local _w = width
    return "width:".._w..",height:".._h..","
end

--- 设置分割线
--- _w  宽度
--- _h  高度
local function line (_w,_h)
    if _w == 1 then
       _w = _w / scale
    end

    if _h == 1 then
        _h = _h / scale
    end
    local line = View()
    line.frame(0,0,_w,_h)
    line.backgroundColor(GRAY_COLOR)
    return line
end

--- onClick事件
--- view 设置响应事件的view
--- data 响应的数据
local function onClick(view,data)
    view.callback(function()
        Toast(data)
    end);
end

--- 分类标题
local function category(data)

    local layout = View()
    local height = unitHeight_C
    layout.frame(0,0,w,height)
    layout.flexCss("flex-direction: row, padding-left:10,padding-right:10,align-items: center, flex-wrap: 1, align-content: flex-start")

    local image = Image()
    --    image.image("http://img4.tbcdn.cn/L1/461/1/img_20151116194256.JPEG_240x240")
    if not isEmpty(data.icon) then
        image.image(data.icon)
    end

    image.flexCss("width: 30, height: 30")
    --view1.size(w,80)



    local title = Label()

    if not isEmpty(data.ceilTitle) then
        title.text(data.ceilTitle)
    else
        title.text(defTitle)
    end

    if not isEmpty(data.titleColor) then
        title.textColor(data.titleColor)
    else
        title.textColor(data.titleColor)
    end
    title.fontSize(defCategoryTitle)
    title.lineCount(0)
    title.flexCss("margin-left: 10, sizetofit: 1, align-self: center")

    local moreView = View()
    local desc = Label()
    if not isEmpty(data.descColor) then
        desc.text(data.descTitle)
    else
        desc.text(defSubTitle)
    end

    if not isEmpty(data.descColor) then
        desc.textColor(data.descColor)
    else
        desc.textColor(defSubColor)
    end

    desc.lineCount(0)
    desc.flexCss("sizetofit: 1, align-self: center,margin-right:10")
    local descArrow = Image()
    descArrow.image("arrow_right")
    descArrow.flexCss("width: 10, height: 10,margin-right:10")

    moreView.align(Align.RIGHT)
    moreView.flexCss("flex-direction: row,align-self: center")
    moreView.flexChildren(desc,descArrow)

    if not isEmpty(data.moreLink) then
        onClick(moreView,data.moreLink)
    end


    layout.flexChildren(image,title,moreView)


    return layout
end


--- 水平方向布局的最小单元
--- data  分类数据
--- index 分类.listInfo的下标
local function unitView_H(data,index)

    local info = data.listInfo[index]
--    printTable(info)
    local layout = View()

--    layout.frame(0,0,w/2,unitHeigth_H)
    if not isEmpty(info.backgroundColor) then
        layout.backgroundColor(info.backgroundColor)
    end
    layout.flexCss("flex:1,flex-direction: row, align-items: stretch")

    local leftLayout =  View()
    leftLayout.flexCss("padding-left: 10.0, flex-direction: column,justify-content:center")

    local title = Label()
    if not isEmpty(info.title) then
--        print(isEmpty(info.title))
        title.text(info.title)
    end

    if not isEmpty(info.titleColor) then
        title.textColor(info.titleColor)
    end

    title.fontSize(defCategoryTitle)
    title.lineCount(0)
    title.flexCss("sizetofit: 1")

    local desc = Label()
    if not isEmpty(info.subtitle) then
        desc.text(info.subtitle)
    end
    if not isEmpty(info.subtitleColor) then
        desc.textColor(info.subtitleColor)
    end
    desc.lineCount(0)
    desc.flexCss("sizetofit: 1")


    if not isEmpty(info.tag) then
        local tagView = View()
        local tag = Label()
        tag.text(info.tag)
        tagView.cornerRadius(2)
        tagView.borderWidth(1)
        if not isEmpty(info.titleColor) then
            tag.textColor(info.titleColor)

            tagView.borderColor(info.titleColor)
        else
            tag.textColor(BALACK_COLOR)
            tagView.textColor(BALACK_COLOR)
        end
        tag.lineCount(0)
        tag.flexCss("sizetofit: 1")
        tagView.flexCss("padding:2")
--        tagView.adjustSize()
--        tagView.addView(tag)
        tagView.flexChildren(tag)
        leftLayout.flexChildren(title,desc,tagView)
    else
        leftLayout.flexChildren(title,desc)

    end


    local rightLayout = View()
    rightLayout.align(Align.RIGHT)
    rightLayout.flexCss("justify-content:center,padding-right:10")
    local image = Image()
--    image.image("http://img4.tbcdn.cn/L1/461/1/img_20151116194256.JPEG_240x240")
    if not isEmpty(info.image) then
    image.image(info.image)
        image.frame(0,0,defSmallSize,defSmallSize)
    end
    image.flexCss("align-self:center")
    rightLayout.flexChildren(image)
    layout.flexChildren(leftLayout,rightLayout)

    if not isEmpty(info.link) then
        onClick(layout,info.link)
    end
    return layout
end


--- 竖直方向布局的最小单元
--- data  分类数据
--- index 分类.listInfo的下标
local function unitView_V(data,index)
    local info = data.listInfo[index]
    local layout = View()

    if not isEmpty(info.backgroundColor) then
        layout.backgroundColor(info.backgroundColor)
    end
    layout.flexCss("flex:1,padding: 10.0, flex-direction: column, align-items: stretch")

    -- title
    local title = Label()
    if not isEmpty(info.title) then
        title.text(info.title)
    end
    if not isEmpty(info.titleColor) then
        title.textColor(info.titleColor)
    end
    title.fontSize(defCategoryTitle)
    title.lineCount(0)
    title.flexCss("sizetofit: 1")


    --desc
    local desc = Label()
    if not isEmpty(info.subtitle) then
        desc.text(info.subtitle)
    end
    if not isEmpty(info.subtitleColor) then
        desc.textColor(info.subtitleColor)
    end
    desc.lineCount(0)
    desc.flexCss("sizetofit: 1")


    -- image
    local bottomLayout = View()
    bottomLayout.align(Align.BOTTOM,Align.CENTER)
--    bottomLayout.backgroundColor(GREEN_COLOR)
--    bottomLayout.flexCss("padding-bottom:0")
    local image = Image()
    if not isEmpty(info.image) then
        image.image(info.image)
    end
    --    image.image("http://img4.tbcdn.cn/L1/461/1/img_20151116194256.JPEG_240x240")
    -- index ==1 第一个view 显示 大图
    if index == 1 then
        image.frame(0,0,defBigSize,defBigSize)
    else
        image.frame(0,0,defSmallSize,defSmallSize)

    end
    image.flexCss("align-self:center,margin-bottom:5")
    bottomLayout.flexChildren(image)


    -- tag and addView
    if not isEmpty(info.tag) then
        local tagView = View()
        local tag = Label()
        tag.text(info.tag)
        tagView.cornerRadius(2)
        tagView.borderWidth(1)
        tagView.adjustSize()

        if not isEmpty(info.titleColor) then
            tag.textColor(info.titleColor)
            tagView.borderColor(info.titleColor)
        else
            tagView.borderColor(BALACK_COLOR)
            tag.textColor(BALACK_COLOR)
        end
        tagView.frame(0,0,tag.width(),tag.height())
        tag.lineCount(0)
        tag.flexCss("sizetofit: 1,align-self:stretch")
        tagView.flexCss("padding:2")

        tagView.flexChildren(tag)
        layout.flexChildren(title,desc,tagView,bottomLayout)
    else
        layout.flexChildren(title,desc,bottomLayout)
    end

    if not isEmpty(info.link) then
        onClick(layout,info.link)
    end

    return layout
end


--- 水平方向两个item的view
--- data  分类数据
--- index 数组索引, 默认为1
local function twoItemView(data,index)
    if index == nil then
        index = 1
    end

    local height = unitHeigth_H
    local layout = View()
    local line1 = line(1,height)
    layout.frame(0,0,w,height)
    layout.flexCss("flex:1,flex-direction: row")
    layout.flexChildren(unitView_H(data,index),line1,unitView_H(data,index+1))
    return layout;
end

--- 3个item的布局，用于设置 3 - 5 - 7个item的view
--- 横向 1 大  2 小
--- data  分类数据
local function threeItemView(data)

    local height = unitHeigth_H * 2
    local layout = View()

    local line1 = line(1,height)
    local line2 = line(w/2,1)

    layout.frame(0,0,w,height)
--    layout.backgroundColor(BLUE_COLOR)
    layout.flexCss("flex:1,flex-direction: row")

    local leftLayout = View()
    leftLayout.flexCss("flex:1,flex-direction: column")
    leftLayout.flexChildren(unitView_V(data,1))

    local rightLayout = View()
--    rightLayout.frame(0,0,w,height)
--    rightLayout.backgroundColor(BLUE_COLOR)
    rightLayout.flexCss("flex:1,flex-direction: column")
    rightLayout.flexChildren(unitView_H(data,2),line2,unitView_H(data,3))
    layout.flexChildren(leftLayout,line1,rightLayout)
    return layout;
end

--- 水平方向的 4 个item的 布局
--- 其中每个item中的view为竖直方向排列
--- data  分类数据
local function fourItemView(data)
    local height = unitHeight_V
    local layout = View()
    layout.frame(0,0,w,height)
    --    bottomView.backgroundColor(BLUE_COLOR)
    layout.flexCss("flex-direction: row,justify-content:flex-start")
    local line1 = line(1,height)
    local line2 = line(1,height)
    local line3 = line(1,height)
    local dataLength = #data.listInfo
    layout.flexChildren(unitView_V(data,dataLength-3),line1,unitView_V(data,dataLength-2),line2,unitView_V(data,dataLength-1),line3,unitView_V(data,dataLength))
    return layout
end

--- 分类广告banner
--- data 分类数据
--- TODO 滚动指示器，循环滚动，自动滚动
local function categoryAdsLayout(data)
    local info = data.banner
    local vp = PagerView({
        PageCount = #info,
        Pages = {
            Title = function(pos)
                return "Title"
            end,
            Init = function(page, pos)
                page.banner = Image()
            end,
            Layout = function(page, pos)
                page.banner.image(info[pos].image)
--                page.banner.image("http://h.hiphotos.baidu.com/nuomi/pic/item/d0c8a786c9177f3e90d477f477cf3bc79e3d5663.jpg")
                page.banner.frame(0, 0, w, unitHeight_Ads)
                if not isEmpty(info[pos].link) then
                    onClick(page.banner,info.link)
                end
            end
        },
        Callback = {
            Scrolling=function(pos, percent, distance)
                Toast("滑动"..pos)
            end,
            Selected=function(pos)
                Toast("选中"..pos)
            end
        }
    })


--    local indicator = PagerIndicator()
--    indicator.frame(0,0,w , 20)
--    indicator.pageColor(0xffff0000)
--    indicator.fillColor(0xff0000ff)
--    indicator.radius(10)
--    indicator.strokeWidth(4)
--    indicator.strokeColor(0xff00aaaa)
--    indicator.backgroundColor(0x33333333)
--    indicator.alignCenter()


    vp.frame(0,0,w,unitHeight_Ads)
--    vp.flexCss("align-self:center")
--    vp.indicator(indicator)

    local layout = View()
    layout.frame(0,0,w,unitHeight_Ads)
    layout.flexCss("flex-direction: column,justify-content:flex-start")
    layout.setBackgroundColor(WHITE_COLOR)

    layout.flexChildren(vp)

    return layout
end


local function marginView(height)
    local marginView =  View()
    if height ==nil then

        height = 10
    end
    marginView.frame(0,0,w,height)
    marginView.backgroundColor(GRAY_COLOR)
    marginView.flexCss("flex-direction: column,justify-content:flex-start")
    return marginView
end

--- 分类布局总布局， 包含标题，主题内容，广告
---
local function section(data)
    local layout = View()
    local infoLenght = #data.listInfo
    layout.flexCss("flex-direction: column,justify-content:flex-start")

    -- 没有标题的section
    if data.ceilTitle == nil then
        print("section type category is nil")
        if infoLenght == 3 then
            layout.flexChildren( threeItemView(data),marginView())
        elseif infoLenght == 5 then
            layout.flexChildren( threeItemView(data),line(w,1),twoItemView(data,3),marginView())

        elseif infoLenght == 6 then
            layout.flexChildren( twoItemView(data),line(w,1),twoItemView(data,3),marginView())

        elseif infoLenght == 7 then

            layout.flexChildren( threeItemView(data),line(w,1),fourItemView(data),marginView())
        elseif infoLenght == 8 then

            layout.flexChildren( twoItemView(data),line(w,1),twoItemView(data,3),line(w,1),fourItemView(data),marginView())
        else

        end
    else -- 有标题的section
        if infoLenght == 3 then
            layout.flexChildren(category(data),threeItemView(data),categoryAdsLayout(data),marginView())

        elseif infoLenght == 5 then
            layout.flexChildren(category(data),threeItemView(data),line(w,1),twoItemView(data,3),categoryAdsLayout(data),marginView())

        elseif infoLenght == 6 then
            layout.flexChildren(category(data),twoItemView(data),line(w,1),twoItemView(data,3),categoryAdsLayout(data),marginView())

        elseif infoLenght == 7 then

            layout.flexChildren(category(data),threeItemView(data),line(w,1),fourItemView(data),categoryAdsLayout(data),marginView())
        elseif infoLenght == 8 then

            layout.flexChildren(category(data),twoItemView(data),line(w,1),twoItemView(data,3),line(w,1),fourItemView(data),categoryAdsLayout(data),marginView())
        else

        end
    end

    return layout
end


--- 到店付和每日爆款的View
--- data  分类数据
--- index 分类.listInfo的下标
--- color 副标题颜色  1 蓝色  其他:橘色
local function daoDianfuAndMeiRiBaoKuan(data,index,color)
    local info = data[index]
    local layout = View()
    if info ~= nil then
        layout.flexCss("flex:1,padding:10 ,flex-direction: column, align-items: stretch,justify-content:center")

        -- title
        local title = Image()
        title.align(Align.H_CENTER)
        if not isEmpty(info.titlePictureUrl) then
            title.image(info.titlePictureUrl)
        end
        title.flexCss("align-self: center")
        title.frame(0,0, w / 3 - 40 , 25)

        --desc
        local subview = View()
        subview.cornerRadius(15)

        local desc = Label()
        if not isEmpty(info.subTitle) then
            desc.text(info.subTitle)
        end
        if not isEmpty(info.subTitleColor) then
            desc.textColor(info.subTitleColor)
        end
        desc.align(Align.H_CENTER)
        desc.lineCount(0)
        subview.align(Align.H_CENTER)
        subview.frame(0, 0, desc.width(), desc.height())
        subview.flexCss("flex:1,margin-top:5,padding:5,justify-content:center")
        desc.flexCss("sizetofit: 1,align-self: center")
        if color == nil then
           color = 1
        end
        if color == 1 then
            subview.backgroundColor(T10_BLUE,10)
        else
            subview.backgroundColor(T10_ORANGE,10)
        end
        subview.flexChildren(desc)

        -- image
        local bottomLayout = View()
        bottomLayout.align(Align.BOTTOM,Align.CENTER)
        local image = Image()
        if not isEmpty(info.pictureUrl) then
            image.image(info.pictureUrl)
        end
        image.align(Align.H_CENTER)
        image.frame(0,0,defSmallSize,defSmallSize)
        image.flexCss("align-self:center,margin-bottom:5")
        bottomLayout.flexChildren(image)


        if not isEmpty(info.cont) then
            onClick(layout,info.cont)
        end
        layout.flexChildren(title,subview,bottomLayout)
    end
    return layout
end

--- topten 运营位
--- 到店付和每日爆款的View
--- data  分类数据
--- index 分类.listInfo的下标
--- color 副标题颜色  1 蓝色  其他:橘色
local function topten(data,vip)
    local info = data
    local activetime = info.activetime
    local list = info.list
    printTable(data)
    local index = 1
    local layout = View()
    if info ~= nil then
        layout.flexCss("flex:1,padding:10 ,flex-direction: column, align-items: stretch,justify-content:start")

        -- title
        local title = Image()
        title.align(Align.H_CENTER)
        title.image("top10_buy")
        title.flexCss("align-self: center")
        title.frame(0,0, w / 3 - 30 , 25)

        --timer 倒计时 以及 Vip view
        local timerView = View()

        local timer = Label()
--        timer.text(info.subTitle)

        if vip == nil then
            vip = false
        end


        if vip then
            timer.text("会员抢购不限时")
        else
            timer.text("距结束还有...")
        end
        timer.textColor(BALACK_COLOR)
        timerView.cornerRadius(15)
        timer.align(Align.H_CENTER)
        timer.lineCount(0)
        timerView.frame(0, 0, timer.width(), timer.height())
        timerView.flexCss("margin-top:5,padding:5")
        timer.flexCss("sizetofit: 1,align-self: center")
        timerView.backgroundColor(T10_GRAY,10)
        timerView.flexChildren(timer)

        -- 品牌
        local brand = Label()
        brand.flexCss("sizetofit: 1,align-self: center,margin-top:5")
        if not isEmpty(list[index].brand) then
            brand.text(list[index].brand)
        end

        local priceView = View()
        local current = Label()
        current.flexCss("sizetofit: 1,align-self: center")
        priceView.flexCss("flex-direction: row,justify-content:center,margin-top:5")
        local priceTag = Image()
        if list[index].current_price ~= nil then
            local price = StyledString("￥"..list[index].current_price, {fontColor=0xff0000})
            current.text(price)

        end
        priceTag.frame(0,0,20,10)
        priceTag.flexCss("align-self: center,margin-left:5")
        priceTag.image("top10_price")


        priceView.flexChildren(current,priceTag)
        -- 当前价格
--        local current_price = Lable()
--        current_price.flexCss("sizetofit: 1,align-self: center,margin-top:5")
--        print("str  "..info.list[1].current_price)
--        print("type  "..type(info.list[1].current_price))
--        if info.list[1].current_price ~= nil
--        local current_price = info.list[2].current_price;
--            price.text(10)
--        end

        if not isEmpty(info.cont) then
            onClick(layout,info.target_url)
        end
        layout.flexChildren(title,timerView,brand,priceView)
    end
    return layout
end

--- 头部运营位 包含 topten 和 到店付 、每日惠
local function topOperation(toptenData,daodianfu,meiribaokuan)
    local layout = View()
    layout.frame(0,0,w,unitTopHeight)

    layout.flexCss("flex-direction: row,justify-content:flex-start")
    layout.flexChildren(topten(toptenData,false),daoDianfuAndMeiRiBaoKuan(daodianfu,1,1),daoDianfuAndMeiRiBaoKuan(meiribaokuan,1,2))
    return layout
end




-- 依次从上往下对应
function main()

    local url = "http://10.46.189.18:8075/naserver/home/homepage?terminal_type=android&locate_city_id=100010000&cuid=DA6FB0EECEE2F87ADA8BC424B1FF6AB3%7C731740120598468&os=SDK23&bduss=null&channel=kuangbainuosdk&swidth=1080&sign=80e4cd0677b4af562ba6fa9ed4989636&src_channel=kuang_enter&cityid=100010000&bainuosdk_version_code=153&uuid=ffffffff-fec4-36df-b421-8b1350331bcf&dcps_version_code=1&kuang_city_id=131&v=6.3.2&appid=mapnuoandroid&tn=android&location=40.04882081173552%2C116.28054993461932&net=%22baidu_wifi%22&device=&timestamp=1462958654447&sheight=1920"
    local data
    http = Http()
    http.get(url, {
        query = 1
    }, function(response)
        Json.toTable(response.data(), function(result)

            printTable(result.data.meishiGroup.ceilTitle)
            local topten = result.data.topten
            local daoDianfu = result.data.daoDianfu
            local meiRiBaoKuan = result.data.meiRiBaoKuan
            local activityGroup = result.data.activityGroup
            local meishiGroup = result.data.meishiGroup
            local hotService = result.data.hotService
            local entertainment = result.data.entertainment
--            isEmpty(meishiGroup)
--            print("data str "..activityGroup.ceilTitle)

            local startTime = os.clock()

            local layout = View()
            layout.backgroundColor(WHITE_COLOR)
--            layout.frame(0,0,w,1200)
            layout.flexCss("flex-direction: column,justify-content:flex-start")
            layout.flexChildren(topOperation(topten,daoDianfu,meiRiBaoKuan),marginView(),section(activityGroup),section(entertainment),section(hotService),section(meishiGroup))
--            layout.flexChildren()
----            layout.backgroundColor(BLUE_COLOR)


            local endTime = os.clock()
            print(((endTime - startTime) * 1000).."ms")
        end)
    end)
end

main()
